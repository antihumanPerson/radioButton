//
//  radioButtonView.m
//  Yeos
//
//  Created by 潘东 on 16/5/23.
//  Copyright © 2016年 Dream. All rights reserved.
//

#import "radioButtonView.h"
@interface radioButtonView ()
{
    CGFloat x;
    CGFloat y;
    CGFloat w;
    CGFloat h;
    CGFloat gap;
}
@property (strong, nonatomic) UIButton *btn;//用于记录选中按钮
@end
@implementation radioButtonView
//拿到按钮个数循环创建按钮
-(void)setBtnTitleArr:(NSMutableArray *)btnTitleArr
{
    for (int i = 0 ; i < btnTitleArr.count; i++) {
        UIButton *btn = [[UIButton alloc]init];
        [btn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];//普通状态
        [btn setBackgroundImage:[UIImage imageNamed:@"unchecked"] forState:UIControlStateNormal];
        
        [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];//选中状态
        [btn setBackgroundImage:[UIImage imageNamed:@"checked"] forState:UIControlStateSelected];
        
        //按钮文字
        [btn setTitle:btnTitleArr[i] forState:UIControlStateNormal];
        btn.titleLabel.font = [UIFont systemFontOfSize:12.0f];//按钮文字大小
        btn.titleEdgeInsets = UIEdgeInsetsMake(0, 0, 4, 0);//文字偏移量
        btn.showsTouchWhenHighlighted=YES;//特效
        if (i == 0) {// 如果是第一个设置他选中状态
            btn.selected = YES;
            self.btn = btn;
        }
        [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        btn.tag = i;
        btn.frame = CGRectMake(x, y, w, h);
        y += h + gap;
        [self addSubview:btn];
    }
}
//处理按钮点击事件
-(void)btnClick:(UIButton *)btn
{
    if (self.returnBtnClickBlock) {//把按钮标题return出去
        self.returnBtnClickBlock(btn.titleLabel.text);
    }
    btn.selected = YES;//设置选中状态
    if (btn.tag != self.btn.tag) {//如果不是选中了上一次选中的按钮就把选中状态改为no
        self.btn.selected = NO;
    }
    self.btn = btn;//记录上一次选中的按钮
}
-(void)returnBtnClickBlock:(ReturnBtnClick)block
{
    if (block) {
        self.returnBtnClickBlock = block;
    }
}
-(instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        w = 0.0;
        y = 0.0;
        w = 100;
        h = 24;
        gap = 8;
    }
    return self;
}
@end
